/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.chapt4_methods;

/**
 *
 * @author kevmm
 */
public class MyMath {
    public static double calcPower(double time, double watt)
    {
        double power;
        power = time * watt;
        return power;
    }
    public static double calcMomentum(double mass, double velocity)
    {
        double momentum;
        momentum = mass * velocity;
        return momentum;
    }
    
    public static double calcWeight(double mass2, double gravity)
    {
                double weight;
                weight = gravity * mass2;
                return weight;
    }
    
}


